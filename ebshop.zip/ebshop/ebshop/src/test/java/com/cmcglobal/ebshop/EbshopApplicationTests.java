package com.cmcglobal.ebshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
